/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */

const Header = ({title}) => {
  return (
    <div className="w-full py-8 bg-slate-100 text-center text-2xl font-bold ">{title}</div>
  )
}

export default Header